package dio.springboot;

public class MyApplication {
    private Calculadora calculadora;
}
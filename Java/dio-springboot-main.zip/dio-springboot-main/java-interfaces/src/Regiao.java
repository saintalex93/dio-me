public enum Regiao {
    NORTE,
    NORDESTE,
    SUL,
    SUDESTE
    ;
}

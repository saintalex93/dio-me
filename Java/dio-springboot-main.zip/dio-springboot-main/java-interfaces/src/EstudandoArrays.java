public class EstudandoArrays {
    public static void main(String[] args) {
        String [] alunos = new String[]{"MARCOS","FERNANDA"};
        for(String aluno:alunos){
            System.out.println(aluno);
        }
    }
}
